package models;

public class Yorum {

}
