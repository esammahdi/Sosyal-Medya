package models;

import java.util.Date;

public class Kullanici {

	private String ad;
	private String soyad;
	private String sifre;
	private String kisiselFoto;
	private String kullaniciAdi;
	private Date dogumTarihi;
	private String telefonNo;

	public String getKullaniciAdi() {
		return kullaniciAdi;
	}

	public void setKullaniciAdi(String kullaniciAdi) {
		this.kullaniciAdi = kullaniciAdi;
	}

	public String getAd() {
		return ad;
	}

	public void setAd(String ad) {
		this.ad = ad;
	}

	public String getFoto() {
		return kisiselFoto;
	}

	public void setFoto(String foto) {
		this.kisiselFoto = foto;
	}

}
