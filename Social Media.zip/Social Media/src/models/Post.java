package models;

public class Post {

	private Kullanici sahib;
	private String tarih;
	private String foto;
	private int begenmeSayisi;
	private int yorumSayisi;
	private String metin;
	private String ID;

	public boolean begenildiMi(String k) {

		return false;
	}

	public Kullanici getSahib() {
		return sahib;
	}

	public void setSahib(Kullanici sahib) {
		this.sahib = sahib;
	}

	public String getTarih() {
		return tarih;
	}

	public void setTarih(String tarih) {
		this.tarih = tarih;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public int getBegenmeSayisi() {
		return begenmeSayisi;
	}

	public void setBegenmeSayisi(int begenmeSayisi) {
		this.begenmeSayisi = begenmeSayisi;
	}

	public int getYorumSayisi() {
		return yorumSayisi;
	}

	public void setYorumSayisi(int yorumSayisi) {
		this.yorumSayisi = yorumSayisi;
	}

	public String getMetin() {
		return metin;
	}

	public void setMetin(String metin) {
		this.metin = metin;
	}

}
