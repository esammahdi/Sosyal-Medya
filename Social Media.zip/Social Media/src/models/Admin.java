package models;

public class Admin extends Kullanici {

}
