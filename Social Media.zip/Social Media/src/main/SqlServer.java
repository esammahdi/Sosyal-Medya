package main;

import models.Kullanici;
import models.Post;

public class SqlServer {

	String url;
	String userName;
	String pass;

//	------------------------------------------------------------------------------------------------------------------

	public void KullaniciEkle(Kullanici k) {

	}

	public void KullaniciSil(Kullanici k) {

	}

	public void ArkadasEkle(String KullaniciID) {

	}

	public void ArkadasSil(String KullaniciID) {

	}

	public void SifreDegistir(Kullanici k, String yeniSifre) {

	}

//	------------------------------------------------------------------------------------------------------------------

	public void postEkle(Kullanici k, Post p) {

	}

	public void postSil(Kullanici k, String PostID) {

	}

	public void getPostlar(int defa, Kullanici k) {

	}

	public void BegeniAt(Kullanici k, String PostID) {

	}

	public void BegeniSil(Kullanici k, String PostID) {

	}

//	------------------------------------------------------------------------------------------------------------------

}
