package main;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import models.Kullanici;

public class main extends Application {

	public static String KullaniciAdi;
	public static Kullanici AktifKullanici; // Basarili giris yaptiktan sonra yeni bir nesne olusturulacak ve ona
											// veritabanindan giris yapan kullanicinin bilgileri atanacak

	public static void main(String[] args) {
		Application.launch(args);
	}

	public void start(Stage st) {

		Parent root;

		try {
			root = FXMLLoader.load(getClass().getResource("/views/giris.fxml"));
			st.setScene(new Scene(root, 380, 410));
			st.setTitle("Sosyal Media");
			st.show();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
