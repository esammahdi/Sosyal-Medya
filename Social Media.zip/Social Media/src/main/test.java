package main;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import models.RippleLabel;

public class test extends Application {

	@Override
	public void start(Stage st) throws Exception {

		GridPane gp = new GridPane();
		RippleLabel rlabel = new RippleLabel("Deneme 1");
		gp.getChildren().add(rlabel);

		st.setScene(new Scene(gp));
		st.show();

	}

	public static void main(String[] args) {
		launch(args);
	}

}
