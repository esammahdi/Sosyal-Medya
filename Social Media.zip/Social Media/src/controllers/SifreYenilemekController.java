package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class SifreYenilemekController {

	@FXML
	private TextField yeniSifre;

	@FXML
	private TextField yeniSifreTekrari;

	String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=SosyalMedya;user=esam;password=1234";
	ResultSet rs;
	Connection con;
	Statement stmt;

	@FXML
	void sifreSifirla(ActionEvent event) {

		try {

			if (yeniSifre.getText().isBlank() || yeniSifreTekrari.getText().isBlank()) {
				// Dialogue : Butun Alanlar Doldurulmalidir!
				System.out.println("Alanlardan birisi hatali!");
				return;
			}

			if (!yeniSifre.getText().equals(yeniSifreTekrari.getText())) {
				// Dialogue : Butun Alanlar Doldurulmalidir!
				System.out.println("Sifreler Ayni Olmali!");
				return;
			}

			String SQL = "UPDATE Kullanicilar SET Sifre = '" + yeniSifre.getText() + "' WHERE KullaniciID = '"
					+ main.main.KullaniciAdi + "' ";
			con = DriverManager.getConnection(connectionUrl);
			stmt = con.createStatement();
			stmt.executeQuery(SQL);
			// Dialogue : Sifre Basariyla Degistirildi
			System.out.println("Sifre Basariyla Degistirildi");

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
