package controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.ZoneId;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SifreController {

	@FXML
	private TextField Ad;

	@FXML
	private DatePicker DogumTarihi;

	@FXML
	private TextField KullaniciID;

	@FXML
	private TextField Soyad;

	@FXML
	private TextField adminAd;

	@FXML
	private DatePicker adminDogumTarihi;

	@FXML
	private TextField adminID;

	@FXML
	private Button adminSifreDegistirBtn;

	@FXML
	private TextField adminSoyad;

	@FXML
	private Button sifreDegistirBtn;

	String KullaniciAdi;
	String ad;
	String soyad;
	LocalDate dogumTarihi;

	String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=SosyalMedya;user=esam;password=1234";
	ResultSet rs;
	Connection con;
	Statement stmt;

	@FXML
	void sifreDegistir(ActionEvent event) {

		KullaniciAdi = KullaniciID.getText();
		ad = Ad.getText();
		soyad = Soyad.getText();
		dogumTarihi = DogumTarihi.getValue();

		/* Validate : Butun Alanlar Dolu Mu */
		if (KullaniciAdi.isBlank() || ad.isBlank() || soyad.isBlank() || dogumTarihi == null) {
			// Dialogue : Butun Alanlar Doldurulmalidir!
			return;
		}

		try {

			String validateKullaniciAdi = "Select COUNT(*) FROM Kullanicilar where KullaniciID = '" + KullaniciAdi
					+ "' ";
			con = DriverManager.getConnection(connectionUrl);
			stmt = con.createStatement();
			rs = stmt.executeQuery(validateKullaniciAdi);
			rs.next();

			/* Validate : Kullanici Adi Dogru Mu */
			if (rs.getInt(1) == 0) {
				System.out.println("Kullanici Adi Hatali");
				// Dialogue : Kullanici Adi Hatali !
				return;
			}

			String SQL = "SELECT * FROM Kullanicilar WHERE KullaniciID = '" + KullaniciAdi + "' ";
			rs = stmt.executeQuery(SQL);
			rs.next();
			java.util.Date dTarihi = new java.util.Date(rs.getDate("DogumTarihi").getTime());
			LocalDate LocalDogumTarihi = dTarihi.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			/* Validate : Butun bilgiler dogru mu */
			if (!ad.equals(rs.getString("Ad")) || !soyad.equals(rs.getString("Soyad"))
					|| !LocalDogumTarihi.equals(dogumTarihi)) {
				// Dialogue : Butun Alanlar Dogru Olmali!
				System.out.println("Alanlardan birisi hatali!");
				return;
			}

			/* Action : Tum Alanlar dogru ise SifremiUnuttum2 ekranina yonlendir */
			main.main.KullaniciAdi = KullaniciAdi;

			Parent root = FXMLLoader.load(getClass().getResource("/views/sifreUnuttum2.fxml"));
			Stage st = new Stage();
			st.setScene(new Scene(root));
			st.setTitle("Sifre Yenile");
			st.show();

		} catch (SQLException | IOException ex) {
			ex.printStackTrace();
		}
	}

	@FXML
	void geri(ActionEvent event) {

	}

}
