package controllers;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Circle;

public class BilgilerimController implements Initializable {

	@FXML
	private TextField KullaniciAd;

	@FXML
	private TextField ad;

	@FXML
	private Label arkadasSayisi;

	@FXML
	private DatePicker dTarihi;

	@FXML
	private ImageView foto;

	@FXML
	private Button geri;

	@FXML
	private Button guncelle;

	@FXML
	private Label postSayisi;

	@FXML
	private TextField soyad;

	@FXML
	private TextField telefon;

	@FXML
	private ImageView uploadFoto;

	Image hesapFotosu;
	Image defaultHesapFotosu = new Image("resources/images/user.png");

	String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=SosyalMedya;user=esam;password=1234";
	ResultSet rs;
	Connection con;
	Statement stmt;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		Circle clip = new Circle(150.0);
		foto.setClip(clip);

		try {

			String SQL = "SELECT * FROM Kullanicilar WHERE KullaniciID = '" + main.main.KullaniciAdi + "' ";

			con = DriverManager.getConnection(connectionUrl);
			stmt = con.createStatement();

			rs = stmt.executeQuery(SQL);
			rs.next();

			String Ad = rs.getString("Ad");
			String Soyad = rs.getString("Soyad");
			String kullaniciAdi = rs.getString("KullaniciID");
			String Telefon = rs.getString("Telefon");

			java.util.Date dogumTarihi = new java.util.Date(rs.getDate("DogumTarihi")
					.getTime()); /* rs.getDate() sql.Date donduruyor.Onu java.util.Date'e cevirmek lazim. */

			LocalDate LocalDogumTarihi = dogumTarihi.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			if (rs.getBinaryStream("Foto") != null) {
				hesapFotosu = new Image(rs.getBinaryStream("Foto"));
				foto.imageProperty().set(hesapFotosu);
			} else {
				foto.imageProperty().set(defaultHesapFotosu);
			}

			ad.setText(Ad);
			soyad.setText(Soyad);
			KullaniciAd.setText(kullaniciAdi);
			telefon.setText(Telefon);
			dTarihi.setValue(LocalDogumTarihi);

		}
		// Handle any errors that may have occurred.
		catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
