package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class GirisController implements Initializable {

	@FXML
	private Button admiinGiris;

	@FXML
	private TextField adminAdi;

	@FXML
	private PasswordField adminSifresi;

	@FXML
	private Label hesapOlustur;

	@FXML
	private TextField kullaniciAdi;

	@FXML
	private Button kullaniciGiris;

	@FXML
	private PasswordField kullaniciSifresi;

	@FXML
	private Label sifreUnuttum;

	@FXML
	private Label sifreUnuttumAdmin;

	String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=SosyalMedya;user=esam;password=1234";
	ResultSet rs;
	Connection con;
	Statement stmt;

	@FXML
	void AdminGiris(ActionEvent event) {

	}

	@FXML
	void KullaniciGiris(ActionEvent event) {

		String KullaniciAdi = kullaniciAdi.getText();
		String Sifre = kullaniciSifresi.getText();

		if (KullaniciAdi.isBlank() || Sifre.isBlank()) {
			// Dialogue : Bos Olamaz!
			System.out.println("Bos Olamaz!");
			return;
		}

		try {

			con = DriverManager.getConnection(connectionUrl);
			stmt = con.createStatement();
			String getKullaniciAdi = "Select COUNT(*) FROM Kullanicilar where KullaniciID = '" + KullaniciAdi + "' ";

			rs = stmt.executeQuery(getKullaniciAdi);
			rs.next();

			int a = rs.getInt(1);

			if (a == 0) {
				// Dialogue : Yanlis Kullanici Adi veya Sifre
				System.out.println("Yanlis Kullanici Adi veya Sifre!");
				return;
			}

			String getSifre = "SELECT Sifre FROM Kullanicilar WHERE KullaniciID = '" + KullaniciAdi + "' ";
			rs = stmt.executeQuery(getSifre);
			rs.next();
			getSifre = rs.getString(1);

			if (!getSifre.equals(Sifre)) {
				// Dialogue : Yanlis Kullanici Adi veya Sifre
				System.out.println("Yanlis Kullanici Adi veya Sifre 2!");
				return;
			}

			main.main.KullaniciAdi = KullaniciAdi;
			Parent root = FXMLLoader.load(getClass().getResource("/views/bilgilerim.fxml"));
			Stage st = new Stage();
			st.setScene(new Scene(root));
			st.setTitle("Bilgilerim");
			st.show();

		} catch (SQLException | IOException ex) {
			ex.printStackTrace();
		}

	}

	@FXML
	void hesapOlustur(MouseEvent event) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/views/hesapOlustur.fxml"));
			Stage st = new Stage();
			st.setScene(new Scene(root));
			st.setTitle("Hesap Olustur");
			st.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void sifreUnuttum(MouseEvent event) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/views/sifremiUnuttum.fxml"));
			Stage st = new Stage();
			st.setScene(new Scene(root));
			st.setTitle("Sifre Yenilemek");
			st.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void sifreUnuttumAdmin(MouseEvent event) {

	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

	}

}
