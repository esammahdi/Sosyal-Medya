package controllers;

public class AdminController {

}
