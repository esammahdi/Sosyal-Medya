package controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.FileChooser;

public class hesapController implements Initializable {

	@FXML
	private ToggleGroup Cinsiyet;

	@FXML
	private RadioButton erkek;

	@FXML
	private RadioButton kadin;

	@FXML
	private TextField sifre;

	@FXML
	private TextField sifreTekrar;

	@FXML
	private TextField FotoPath;

	@FXML
	private TextField KullaniciAdi;

	@FXML
	private TextField ad;

	@FXML
	private DatePicker dogumTarihi;

	@FXML
	private Button hesapOlusturBtn;

	@FXML
	private TextField soyad;

	@FXML
	private TextField telefonNumarasi;

	@FXML
	private Button yukleBtn;

	String KullaniciAd;
	String Ad;
	String Soyad;
	String Sifre;
	String SifreTekrar;
	String Telefon;
	String DogumTarihi;
	int cinsiyet;
	String Foto;
	String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=SosyalMedya;user=esam;password=1234";
	File hesapFotosu;
	FileChooser fChooser;
	FileInputStream fStream;
	java.sql.Date dTarihi;
	PreparedStatement ps;
	ResultSet rs;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		fChooser = new FileChooser();
		fChooser.setTitle("Personel Foto Secimi");
		fChooser.setInitialDirectory(new File(System.getProperty("user.home")));
		fChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("JPG", "*.jpg"),
				new FileChooser.ExtensionFilter("PNG", "*.png"));

	}

	@FXML
	void hesapOlustur(ActionEvent event) {

		KullaniciAd = KullaniciAdi.getText();
		Ad = ad.getText();
		Soyad = soyad.getText();
		Telefon = telefonNumarasi.getText();
		Sifre = sifre.getText();
		SifreTekrar = sifreTekrar.getText();

		if (validate() == 0) return;

		try (Connection con = DriverManager.getConnection(connectionUrl); Statement stmt = con.createStatement();) {

			String validateKullaniciAdi = "Select COUNT(*) FROM Kullanicilar where KullaniciID = '" + KullaniciAdi
					+ "' ";

			rs = stmt.executeQuery(validateKullaniciAdi);
			rs.next();

			int i = rs.getInt(1);

			if (i != 0) {
				System.out.println("Hesap YOK");
				// Dialogue : Kullanici Adi Zaten Var!
				return;
			}

			String SQL = "INSERT INTO Kullanicilar (KullaniciID,Ad,Soyad,Telefon,Sifre,DogumTarihi,Cinsiyet,Foto) VALUES(?,?,?,?,?,?,?,?)";

			dTarihi = java.sql.Date.valueOf(dogumTarihi.getValue());

			ps = con.prepareStatement(SQL);
			ps.setString(1, KullaniciAd);
			ps.setString(2, Ad);
			ps.setString(3, Soyad);
			ps.setString(4, Telefon);
			ps.setString(5, Sifre);
			ps.setDate(6, dTarihi);
			if (erkek.isSelected())
				ps.setBoolean(7, true);
			else
				ps.setBoolean(7, false);

			if (fStream != null)
				ps.setBinaryStream(8, fStream, fStream.available());
			else
				ps.setBinaryStream(8, fStream, 5);

			ps.execute();
			// Dialogue : Hesap Basariyla Olusturuldu!!!!!!!!!!!!!

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

	}

	private int validate() {

		if (KullaniciAd.isBlank() || Ad.isBlank() || Soyad.isBlank() || Telefon.isBlank() || Sifre.isBlank()
				|| SifreTekrar.isBlank() || (!erkek.isSelected() && kadin.isSelected())
				|| dogumTarihi.getValue() == null) {

			// Dialogue : Butun Alanlar Doldurulmalidir!

			return 0;
		}

		if (!Sifre.equals(SifreTekrar)) {

			// Dialogue : Sifre ve Sifre Tekrari Ayni Olmalidir.

			return 0;
		}

		return 1;
	}

	@FXML
	void fotoYukle(ActionEvent event) {
		hesapFotosu = fChooser.showOpenDialog(yukleBtn.getScene().getWindow());
		if (hesapFotosu != null) {
			FotoPath.setText(hesapFotosu.getAbsolutePath());
			try {
				fStream = new FileInputStream(hesapFotosu);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

}
