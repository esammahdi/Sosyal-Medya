package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import models.Kullanici;
import models.Post;

public class KullaniciController implements Initializable {

	@FXML
	private Label kullaniciAdiLabel;

	@FXML
	private ImageView kullaniciFotosuOrta;

	@FXML
	private ImageView kullaniciFotosuSide;

	@FXML
	private VBox postContainer;

	List<Post> posts;

	String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=SosyalMedya;user=esam;password=1234";
	ResultSet rs;
	Connection con;
	Statement stmt;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		posts = new ArrayList<>(getPosts(""));

		try {
			for (Post p : posts) {
				FXMLLoader fxml = new FXMLLoader();
				fxml.setLocation(getClass().getResource("/views/post.fxml"));
				VBox root = fxml.load();
				PostController pControll = fxml.getController();
				pControll.setData(p);
				postContainer.getChildren().add(root);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public List<Post> getPosts(String KullaniciID) {
		List<Post> ls = new ArrayList<>();

		Post post = new Post();
		Kullanici k = new Kullanici();
		k.setAd("Esam Mahid");
		k.setKullaniciAdi("Jeen KiZama");
		k.setFoto("resources/images/user_48px.png");
		post.setBegenmeSayisi(55);
		post.setMetin("Ilk Postumuzu yaziyoruz gerisi de geliyor...");
		post.setTarih("15/07/2021");
		post.setYorumSayisi(0);
//		post.setFoto("resources/images/mountain-g12f750297_640.jpg");
		post.setSahib(k);
		ls.add(post);

		for (int i = 0; i < 5; i++) {
			post = new Post();
			k = new Kullanici();
			k.setAd("Esam Mahid");
			k.setKullaniciAdi("Jeen KiZama");
			k.setFoto("resources/images/user_48px.png");
			post.setBegenmeSayisi(55);
			post.setMetin("Ilk Postumuzu yaziyoruz gerisi de geliyor...");
			post.setTarih("15/07/2021");
			post.setYorumSayisi(98);
			post.setFoto("resources/images/mountain-g12f750297_640.jpg");
			post.setSahib(k);
			ls.add(post);
		}

		return ls;
	}

}
