package controllers;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import models.Kullanici;
import models.Post;

public class PostController implements Initializable {

	@FXML
	private VBox yorumBox;

	@FXML
	private ImageView begenFotosu;

	@FXML
	private HBox begenmeContainer;

	@FXML
	private Label begenmeSayisi;

	@FXML
	private ImageView postAyarlari;

	@FXML
	private ImageView postFotosu;

	@FXML
	private Label postKullaniciAdi;

	@FXML
	private ImageView postKullaniciFotosu;

	@FXML
	private Label postTarihi;

	@FXML
	private Label postYazisi;

	@FXML
	private ImageView tepkiFotosu;

	@FXML
	private ImageView yorumFotosu;

	@FXML
	private Label yorumSayisi;

	String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=SosyalMedya;user=esam;password=1234";
	ResultSet rs;
	Connection con;
	Statement stmt;

	Image begenmeOutline = new Image("resources/images/ic_like_outline.png");
	Image begenme = new Image("resources/images/ic_like.png");

	@Override
	public void initialize(URL location, ResourceBundle resources) {
//		setData(getPost());

	}

	public void setData(Post p) {
		postYazisi.setText(p.getMetin());
		postTarihi.setText(p.getTarih());
		if (p.getFoto() != null) {
			Image f = new Image(p.getFoto());
			postFotosu.setImage(f);
		} else {
			postFotosu.setVisible(false);
			postFotosu.setManaged(false);
		}

		if (p.getYorumSayisi() > 0) {

		} else {
			yorumBox.setVisible(false);
			yorumBox.setManaged(false);
		}

		yorumSayisi.setText(p.getYorumSayisi() + " Yorum");
		begenmeSayisi.setText(p.getBegenmeSayisi() + " Begeni");
		postKullaniciAdi.setText(p.getSahib().getKullaniciAdi());

		if (p.getSahib().getFoto() != null) {
			Image f = new Image(p.getSahib().getFoto());
			postKullaniciFotosu.setImage(f);
		}

		if (p.begenildiMi(main.main.KullaniciAdi)) {
			begenFotosu.setImage(begenme);
		} else {
			begenFotosu.setImage(begenmeOutline);
		}

		postTarihi.setText(p.getTarih());

	}

	private Post getPost() {
		Post post = new Post();
		Kullanici k = new Kullanici();
		k.setAd("Esam Mahid");
		k.setKullaniciAdi("Jeen KiZama");
		k.setFoto("resources/images/user_48px.png");
		post.setBegenmeSayisi(55);
		post.setMetin("Ilk Postumuzu yaziyoruz gerisi de geliyor...");
		post.setTarih("15/07/2021");
		post.setYorumSayisi(98);
		post.setFoto("resources/images/mountain-g12f750297_640.jpg");
		post.setSahib(k);
		return post;
	}

}
