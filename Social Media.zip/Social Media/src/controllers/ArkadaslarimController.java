package controllers;

public class ArkadaslarimController {

}
